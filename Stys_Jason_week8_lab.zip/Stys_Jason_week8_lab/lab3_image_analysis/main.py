from google.cloud import storage
from google.cloud import vision
import os

vision_client = vision.ImageAnnotatorClient()
storage_client = storage.Client()

OUTPUT_BUCKET = os.environ.get("OUTPUT_BUCKET")


def analyze_image(event, context):
    """Triggered on GCS file upload to analyze an image."""
    bucket_name = event["bucket"]
    file_name = event["name"]

    if not OUTPUT_BUCKET:
        raise ValueError("OUTPUT_BUCKET env var not set.")

    image = vision.Image()
    image.source.image_uri = f"gs://{bucket_name}/{file_name}"

    response = vision_client.label_detection(image=image)

    if response.error.message:
        raise RuntimeError(response.error.message)

    labels = [label.description for label in response.label_annotations]

    if labels:
        print(f"Labels found: {', '.join(labels)}")
        output_content = "Labels:\n" + "\n".join(labels)
    else:
        print(f"No labels found for {file_name}.")
        output_content = "Labels:\nNo labels found"

    output_blob = storage_client.bucket(OUTPUT_BUCKET).blob(f"results-{file_name}.txt")
    output_blob.upload_from_string(output_content)

    print(f"Results saved for {file_name}.")
