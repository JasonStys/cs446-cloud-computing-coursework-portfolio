#!/bin/bash
set -euo pipefail

REGION="${REGION:-us-central1}"
INPUT_BUCKET="${INPUT_BUCKET:?Set INPUT_BUCKET first}"
OUTPUT_BUCKET="${OUTPUT_BUCKET:?Set OUTPUT_BUCKET first}"
TEST_IMAGE="${TEST_IMAGE:-sample-image.jpg}"

gcloud storage cp "$TEST_IMAGE" "gs://${INPUT_BUCKET}"
sleep 15
gcloud functions logs read image-analyzer --region="$REGION" --limit=20
echo
gcloud storage ls "gs://${OUTPUT_BUCKET}"
echo
gcloud storage cat "gs://${OUTPUT_BUCKET}/results-${TEST_IMAGE}.txt"
