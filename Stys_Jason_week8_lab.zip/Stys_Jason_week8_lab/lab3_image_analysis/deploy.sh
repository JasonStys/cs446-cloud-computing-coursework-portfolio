#!/bin/bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:?Set PROJECT_ID first}"
REGION="${REGION:-us-central1}"
INPUT_BUCKET="${INPUT_BUCKET:?Set INPUT_BUCKET first}"
OUTPUT_BUCKET="${OUTPUT_BUCKET:?Set OUTPUT_BUCKET first}"

gcloud config set project "$PROJECT_ID"

gcloud services enable   cloudfunctions.googleapis.com   cloudbuild.googleapis.com   storage.googleapis.com   logging.googleapis.com   eventarc.googleapis.com   vision.googleapis.com

gcloud storage buckets create "gs://${INPUT_BUCKET}" --location="$REGION"
gcloud storage buckets create "gs://${OUTPUT_BUCKET}" --location="$REGION"

gcloud functions deploy image-analyzer   --no-gen2   --region="$REGION"   --runtime=python310   --entry-point=analyze_image   --trigger-resource="$INPUT_BUCKET"   --trigger-event=google.storage.object.finalize   --set-env-vars "OUTPUT_BUCKET=${OUTPUT_BUCKET}"   --source=.
