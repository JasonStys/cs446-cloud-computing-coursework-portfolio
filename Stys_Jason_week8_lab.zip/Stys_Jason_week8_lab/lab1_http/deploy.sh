#!/bin/bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:?Set PROJECT_ID first}"
REGION="${REGION:-us-central1}"

gcloud config set project "$PROJECT_ID"

gcloud services enable   cloudfunctions.googleapis.com   cloudbuild.googleapis.com   storage.googleapis.com   logging.googleapis.com

gcloud functions deploy hello-http   --no-gen2   --region="$REGION"   --runtime=python310   --entry-point=hello_get   --trigger-http   --allow-unauthenticated   --source=.
