#!/bin/bash
set -euo pipefail

REGION="${REGION:-us-central1}"

FUNCTION_URL="$(gcloud functions describe hello-http --region="$REGION" --format='value(httpsTrigger.url)')"
echo "Function URL: $FUNCTION_URL"
curl -s "$FUNCTION_URL"
echo
