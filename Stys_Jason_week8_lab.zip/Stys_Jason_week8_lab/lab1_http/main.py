def hello_get(request):
    """HTTP Cloud Function.

    Args:
        request (flask.Request): The request object.

    Returns:
        str: The response text.
    """
    return "Hello from a Cloud Function!"
