def process_gcs_event(event, context):
    """Background Cloud Function triggered by Cloud Storage.

    Args:
        event (dict): Event payload.
        context (google.cloud.functions.Context): Event metadata.
    """
    file_name = event["name"]
    bucket_name = event["bucket"]

    print(f"File '{file_name}' was uploaded to '{bucket_name}'.")
    print(f"Event ID: {context.event_id}")
