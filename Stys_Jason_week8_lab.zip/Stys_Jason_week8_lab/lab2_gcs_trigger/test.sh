#!/bin/bash
set -euo pipefail

REGION="${REGION:-us-central1}"
TRIGGER_BUCKET="${TRIGGER_BUCKET:?Set TRIGGER_BUCKET first}"

echo "Cloud Functions Lab 2 test file" > gcf-test.txt
gcloud storage cp gcf-test.txt "gs://${TRIGGER_BUCKET}"
sleep 10
gcloud functions logs read log-gcs-upload --region="$REGION" --limit=20
