#!/bin/bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:?Set PROJECT_ID first}"
REGION="${REGION:-us-central1}"
TRIGGER_BUCKET="${TRIGGER_BUCKET:?Set TRIGGER_BUCKET first}"

gcloud config set project "$PROJECT_ID"

gcloud services enable   cloudfunctions.googleapis.com   cloudbuild.googleapis.com   storage.googleapis.com   logging.googleapis.com   eventarc.googleapis.com

gcloud storage buckets create "gs://${TRIGGER_BUCKET}" --location="$REGION"

gcloud functions deploy log-gcs-upload   --no-gen2   --region="$REGION"   --runtime=python310   --entry-point=process_gcs_event   --trigger-resource="$TRIGGER_BUCKET"   --trigger-event=google.storage.object.finalize   --source=.
