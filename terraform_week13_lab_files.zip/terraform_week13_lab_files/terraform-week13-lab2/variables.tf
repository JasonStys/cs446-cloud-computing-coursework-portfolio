variable "project_id" {
  description = "The Google Cloud project ID where Terraform will create resources."
  type        = string
}

variable "gcp_region" {
  description = "The Google Cloud region for the Terraform lab resources."
  type        = string
  default     = "us-central1"
}

variable "gcp_zone" {
  description = "The Google Cloud zone for the Terraform lab VM."
  type        = string
  default     = "us-central1-a"
}

variable "machine_type" {
  description = "The machine type for the Compute Engine VM."
  type        = string
  default     = "e2-micro"
}
