output "vm_public_ip" {
  description = "The public IP address of the Terraform web server VM."
  value       = google_compute_instance.web_server.network_interface[0].access_config[0].nat_ip
}

output "website_url" {
  description = "The URL to visit after Apache finishes installing."
  value       = "http://${google_compute_instance.web_server.network_interface[0].access_config[0].nat_ip}"
}

output "ssh_command" {
  description = "A command that can be used to SSH into the VM from Cloud Shell."
  value       = "gcloud compute ssh ${google_compute_instance.web_server.name} --zone ${var.gcp_zone}"
}
