This package contains the files created or used across the Week 10 NLP labs.

Contents

Lab_1
- sentiment_entities.py
  Standalone Natural Language API test script for sentiment and entity extraction.
- cloud_function/main.py
  Event-driven Cloud Run function source used for automated text analysis.
- cloud_function/requirements.txt
  Python dependencies for the deployed function.
- test_files/
  Five text files uploaded to Cloud Storage for trigger testing.

Lab_2
- imdb_bilstm_vertex_ai.py
  Full Python version of the notebook workflow for preprocessing, training, evaluation, and export.
- imdb_bilstm_vertex_ai_notebook.ipynb
  Jupyter notebook version of the same Lab 2 workflow.
- requirements.txt
  Core Python packages used in the notebook environment.
- request.json
  Example Vertex AI online prediction request payload.
