import functions_framework
from google.cloud import firestore
from google.cloud import language_v2
from google.cloud import storage

nl_client = language_v2.LanguageServiceClient()
db = firestore.Client()
storage_client = storage.Client()


@functions_framework.cloud_event
def analyze_text(cloud_event):
    data = cloud_event.data
    bucket_name = data["bucket"]
    file_name = data["name"]

    if not file_name.lower().endswith(".txt"):
        print(f"Skipping non-text file: {file_name}")
        return

    blob = storage_client.bucket(bucket_name).blob(file_name)
    text = blob.download_as_text()

    document = language_v2.Document(
        content=text,
        type_=language_v2.Document.Type.PLAIN_TEXT,
    )

    sentiment_response = nl_client.analyze_sentiment(
        request={"document": document}
    )
    entity_response = nl_client.analyze_entities(
        request={"document": document}
    )

    sentiment = sentiment_response.document_sentiment

    db.collection("nlp_analysis").document(file_name.replace("/", "_")).set(
        {
            "fileName": file_name,
            "bucket": bucket_name,
            "sentimentScore": sentiment.score,
            "sentimentMagnitude": sentiment.magnitude,
            "entities": [
                {
                    "name": entity.name,
                    "type": entity.type_.name,
                    "salience": entity.salience,
                }
                for entity in entity_response.entities[:10]
            ],
            "textPreview": text[:300],
            "processedAt": firestore.SERVER_TIMESTAMP,
        }
    )

    print(f"Processed {file_name} successfully.")
