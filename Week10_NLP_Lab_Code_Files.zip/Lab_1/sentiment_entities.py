from google.cloud import language_v2

client = language_v2.LanguageServiceClient()

sample_texts = [
    "The movie was brilliant, emotional, and beautifully acted.",
    "The plot was dull, the pacing was slow, and I regretted watching it.",
    "The film opened last night in Los Angeles and stars Emma Stone."
]

for index, text in enumerate(sample_texts, start=1):
    print(f"\n--- Sample {index} ---")
    print(f"Text: {text}")

    document = language_v2.Document(
        content=text,
        type_=language_v2.Document.Type.PLAIN_TEXT,
    )

    sentiment_response = client.analyze_sentiment(request={"document": document})
    sentiment = sentiment_response.document_sentiment

    print(f"Sentiment score: {sentiment.score:.2f}")
    print(f"Sentiment magnitude: {sentiment.magnitude:.2f}")

    entity_response = client.analyze_entities(request={"document": document})

    print("Entities:")
    if not entity_response.entities:
        print("  None found")
    else:
        for entity in entity_response.entities:
            print(
                f"  - {entity.name} | type={entity.type_.name} | salience={entity.salience:.3f}"
            )
