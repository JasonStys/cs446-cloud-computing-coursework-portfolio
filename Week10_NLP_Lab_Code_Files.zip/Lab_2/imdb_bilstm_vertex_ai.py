import os
import re
import string
import numpy as np
import tensorflow as tf
import tensorflow_datasets as tfds

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from tensorflow.keras import Sequential, Input
from tensorflow.keras.layers import Embedding, Bidirectional, LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
import matplotlib.pyplot as plt


MAX_WORDS = 20000
MAX_LEN = 256
EMBEDDING_DIM = 100


def custom_standardization(text):
    text = tf.strings.lower(text)
    text = tf.strings.regex_replace(text, r"<br\s*/?>", " ")
    text = tf.strings.regex_replace(text, f"[{re.escape(string.punctuation)}]", "")
    return text


# Load raw IMDb data
train_ds = tfds.load("imdb_reviews", split="train", as_supervised=True)
test_ds = tfds.load("imdb_reviews", split="test", as_supervised=True)

all_texts = []
all_labels = []

for text, label in tfds.as_numpy(train_ds):
    all_texts.append(text.decode("utf-8"))
    all_labels.append(int(label))

for text, label in tfds.as_numpy(test_ds):
    all_texts.append(text.decode("utf-8"))
    all_labels.append(int(label))

all_texts = np.array(all_texts, dtype=object)
all_labels = np.array(all_labels)

# 80 / 10 / 10 split
X_train, X_temp, y_train, y_temp = train_test_split(
    all_texts,
    all_labels,
    test_size=0.20,
    random_state=42,
    stratify=all_labels
)

X_val, X_test, y_val, y_test = train_test_split(
    X_temp,
    y_temp,
    test_size=0.50,
    random_state=42,
    stratify=y_temp
)

# Vectorization
vectorizer = tf.keras.layers.TextVectorization(
    max_tokens=MAX_WORDS,
    standardize=custom_standardization,
    output_mode="int",
    output_sequence_length=MAX_LEN
)

vectorizer.adapt(X_train)
vocab = vectorizer.get_vocabulary()

X_train_seq = vectorizer(tf.constant(X_train)).numpy()
X_val_seq = vectorizer(tf.constant(X_val)).numpy()
X_test_seq = vectorizer(tf.constant(X_test)).numpy()

# Download GloVe separately before running this section
# !wget -nc https://nlp.stanford.edu/data/glove.6B.zip
# !unzip -n glove.6B.zip
GLOVE_FILE = "glove.6B.100d.txt"
embeddings_index = {}

with open(GLOVE_FILE, "r", encoding="utf-8") as f:
    for line in f:
        values = line.strip().split()
        word = values[0]
        coefs = np.asarray(values[1:], dtype="float32")
        embeddings_index[word] = coefs

vocab_size = len(vocab)
embedding_matrix = np.random.normal(
    loc=0.0, scale=0.05, size=(vocab_size, EMBEDDING_DIM)
).astype("float32")

for i, word in enumerate(vocab):
    if i == 0:
        embedding_matrix[i] = np.zeros((EMBEDDING_DIM,), dtype="float32")
        continue
    vector = embeddings_index.get(word)
    if vector is not None:
        embedding_matrix[i] = vector

model = Sequential([
    Input(shape=(MAX_LEN,)),
    Embedding(
        input_dim=vocab_size,
        output_dim=EMBEDDING_DIM,
        weights=[embedding_matrix],
        trainable=False
    ),
    Bidirectional(LSTM(128, return_sequences=True)),
    Dropout(0.3),
    Bidirectional(LSTM(64)),
    Dropout(0.3),
    Dense(1, activation="sigmoid")
])

model.compile(
    optimizer="adam",
    loss="binary_crossentropy",
    metrics=["accuracy"]
)

early_stopping = EarlyStopping(
    monitor="val_loss",
    patience=3,
    restore_best_weights=True,
    verbose=1
)

checkpoint = ModelCheckpoint(
    filepath="best_bilstm_sentiment.keras",
    monitor="val_loss",
    save_best_only=True,
    mode="min",
    verbose=1
)

history = model.fit(
    X_train_seq,
    y_train,
    validation_data=(X_val_seq, y_val),
    epochs=10,
    batch_size=64,
    callbacks=[early_stopping, checkpoint],
    verbose=1
)

y_prob = model.predict(X_test_seq)
y_pred = (y_prob > 0.5).astype("int32").ravel()

print(classification_report(
    y_test,
    y_pred,
    target_names=["Negative", "Positive"]
))

epochs_ran = range(1, len(history.history["loss"]) + 1)

plt.figure(figsize=(8, 6))
plt.plot(epochs_ran, history.history["loss"], label="Training Loss")
plt.plot(epochs_ran, history.history["val_loss"], label="Validation Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Training and Validation Loss")
plt.legend()
plt.grid(True)
plt.savefig("loss_curves.png")
plt.show()

cm = confusion_matrix(y_test, y_pred)

plt.figure(figsize=(6, 5))
plt.imshow(cm, interpolation="nearest")
plt.title("Confusion Matrix - Bi LSTM Sentiment Classifier")
plt.colorbar()
plt.xticks([0, 1], ["Negative", "Positive"])
plt.yticks([0, 1], ["Negative", "Positive"])
plt.xlabel("Predicted")
plt.ylabel("Actual")

for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        plt.text(j, i, str(cm[i, j]), ha="center", va="center")

plt.tight_layout()
plt.savefig("confusion_matrix.png")
plt.show()

# Export for Vertex AI
LOCAL_EXPORT_DIR = "vertex_saved_model"

if os.path.exists(LOCAL_EXPORT_DIR):
    import shutil
    shutil.rmtree(LOCAL_EXPORT_DIR)

model.export(LOCAL_EXPORT_DIR)

print("Saved model for Vertex AI export.")
