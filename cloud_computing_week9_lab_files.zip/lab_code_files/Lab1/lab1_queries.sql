-- 1) List all students enrolled in a specific course
SELECT s.student_id, s.first_name, s.last_name, s.email, s.gpa
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN courses c ON e.course_id = c.course_id
WHERE c.title = 'Cloud Computing'
ORDER BY s.last_name, s.first_name;

-- 2) Show all courses a particular student is taking
SELECT s.student_id, s.first_name, s.last_name, c.course_id, c.title, c.department, c.credits, c.instructor
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN courses c ON e.course_id = c.course_id
WHERE s.email = 'alice.nguyen@csusm.edu'
ORDER BY c.title;

-- 3) Count the number of students in each course
SELECT c.course_id, c.title, COUNT(e.student_id) AS student_count
FROM courses c
LEFT JOIN enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id, c.title
ORDER BY c.course_id;

-- 4) Find the average GPA of students in each course
SELECT c.course_id, c.title, ROUND(AVG(s.gpa), 2) AS average_gpa
FROM courses c
LEFT JOIN enrollments e ON c.course_id = e.course_id
LEFT JOIN students s ON e.student_id = s.student_id
GROUP BY c.course_id, c.title
ORDER BY c.course_id;

-- 5) List students not enrolled in any course
SELECT s.student_id, s.first_name, s.last_name, s.email, s.gpa
FROM students s
LEFT JOIN enrollments e ON s.student_id = e.student_id
WHERE e.enrollment_id IS NULL
ORDER BY s.last_name, s.first_name;
