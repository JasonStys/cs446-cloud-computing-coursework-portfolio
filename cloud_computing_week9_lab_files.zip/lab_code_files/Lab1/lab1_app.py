import os
import sys
from datetime import date

import psycopg2
from psycopg2 import pool
from psycopg2.extras import RealDictCursor

DB_CONFIG = {
    "host": os.environ.get("DB_HOST"),
    "dbname": os.environ.get("DB_NAME", "enrollment_db"),
    "user": os.environ.get("DB_USER", "postgres"),
    "password": os.environ.get("DB_PASSWORD"),
    "port": int(os.environ.get("DB_PORT", "5432")),
}

missing = [k for k, v in DB_CONFIG.items() if v in (None, "")]
if missing:
    print(f"Missing required environment variables: {missing}")
    sys.exit(1)

connection_pool = pool.SimpleConnectionPool(
    minconn=1,
    maxconn=5,
    **DB_CONFIG
)

def print_rows(title, rows):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)
    if not rows:
        print("No rows returned.")
        return
    for i, row in enumerate(rows, start=1):
        print(f"{i}. {row}")

def fetch_all(query, params=None):
    conn = None
    try:
        conn = connection_pool.getconn()
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            return cur.fetchall()
    except Exception as e:
        print(f"Query failed: {e}")
        return []
    finally:
        if conn:
            connection_pool.putconn(conn)

def enroll_student_in_course(first_name, last_name, email, gpa, course_title, grade=None):
    conn = None
    try:
        conn = connection_pool.getconn()
        conn.autocommit = False

        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO students (first_name, last_name, email, gpa)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (email) DO UPDATE
                SET first_name = EXCLUDED.first_name,
                    last_name = EXCLUDED.last_name,
                    gpa = EXCLUDED.gpa
                RETURNING student_id
                """,
                (first_name, last_name, email, gpa),
            )
            student_id = cur.fetchone()[0]

            cur.execute(
                "SELECT course_id FROM courses WHERE title = %s",
                (course_title,)
            )
            course_row = cur.fetchone()
            if not course_row:
                raise ValueError(f"Course not found: {course_title}")
            course_id = course_row[0]

            cur.execute(
                """
                INSERT INTO enrollments (student_id, course_id, enrolled_date, grade)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (student_id, course_id) DO NOTHING
                """,
                (student_id, course_id, date.today(), grade),
            )

        conn.commit()
        print(f"Enrollment completed for {first_name} {last_name} in {course_title}.")
    except Exception as e:
        if conn:
            conn.rollback()
        print(f"Enrollment failed: {e}")
    finally:
        if conn:
            connection_pool.putconn(conn)

def main():
    students_in_cloud = fetch_all(
        """
        SELECT s.first_name, s.last_name, s.email, s.gpa
        FROM students s
        JOIN enrollments e ON s.student_id = e.student_id
        JOIN courses c ON e.course_id = c.course_id
        WHERE c.title = %s
        ORDER BY s.last_name, s.first_name
        """,
        ("Cloud Computing",),
    )
    print_rows("Students enrolled in Cloud Computing", students_in_cloud)

    course_counts = fetch_all(
        """
        SELECT c.title, COUNT(e.student_id) AS student_count
        FROM courses c
        LEFT JOIN enrollments e ON c.course_id = e.course_id
        GROUP BY c.course_id, c.title
        ORDER BY c.title
        """
    )
    print_rows("Student count by course", course_counts)

    avg_gpa = fetch_all(
        """
        SELECT c.title, ROUND(AVG(s.gpa), 2) AS average_gpa
        FROM courses c
        LEFT JOIN enrollments e ON c.course_id = e.course_id
        LEFT JOIN students s ON e.student_id = s.student_id
        GROUP BY c.course_id, c.title
        ORDER BY c.title
        """
    )
    print_rows("Average GPA by course", avg_gpa)

    enroll_student_in_course(
        first_name="Frank",
        last_name="Soto",
        email="frank.soto@csusm.edu",
        gpa=3.41,
        course_title="Cloud Computing",
        grade="B"
    )

    frank_courses = fetch_all(
        """
        SELECT s.first_name, s.last_name, c.title, e.enrolled_date, e.grade
        FROM students s
        JOIN enrollments e ON s.student_id = e.student_id
        JOIN courses c ON e.course_id = c.course_id
        WHERE s.email = %s
        ORDER BY c.title
        """,
        ("frank.soto@csusm.edu",),
    )
    print_rows("Courses for Frank Soto", frank_courses)

if __name__ == "__main__":
    try:
        main()
    finally:
        connection_pool.closeall()
