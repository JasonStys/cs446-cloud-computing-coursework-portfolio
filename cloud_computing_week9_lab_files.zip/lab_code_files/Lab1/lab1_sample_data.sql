INSERT INTO students (first_name, last_name, email, gpa) VALUES
('Alice', 'Nguyen', 'alice.nguyen@csusm.edu', 3.85),
('Brian', 'Lopez', 'brian.lopez@csusm.edu', 3.20),
('Chloe', 'Patel', 'chloe.patel@csusm.edu', 3.67),
('Daniel', 'Kim', 'daniel.kim@csusm.edu', 2.95),
('Eva', 'Martinez', 'eva.martinez@csusm.edu', 3.48);

INSERT INTO courses (title, department, credits, instructor) VALUES
('Cloud Computing', 'CS', 3, 'Dr. Rivera'),
('Database Systems', 'CS', 3, 'Dr. Chen'),
('Operating Systems', 'CS', 4, 'Dr. Thompson');

INSERT INTO enrollments (student_id, course_id, enrolled_date, grade) VALUES
((SELECT student_id FROM students WHERE email = 'alice.nguyen@csusm.edu'),
 (SELECT course_id FROM courses WHERE title = 'Cloud Computing'),
 '2026-03-24', 'A'),
((SELECT student_id FROM students WHERE email = 'alice.nguyen@csusm.edu'),
 (SELECT course_id FROM courses WHERE title = 'Database Systems'),
 '2026-03-24', 'A'),
((SELECT student_id FROM students WHERE email = 'brian.lopez@csusm.edu'),
 (SELECT course_id FROM courses WHERE title = 'Cloud Computing'),
 '2026-03-24', 'B'),
((SELECT student_id FROM students WHERE email = 'chloe.patel@csusm.edu'),
 (SELECT course_id FROM courses WHERE title = 'Operating Systems'),
 '2026-03-24', 'A'),
((SELECT student_id FROM students WHERE email = 'chloe.patel@csusm.edu'),
 (SELECT course_id FROM courses WHERE title = 'Database Systems'),
 '2026-03-24', 'B'),
((SELECT student_id FROM students WHERE email = 'daniel.kim@csusm.edu'),
 (SELECT course_id FROM courses WHERE title = 'Cloud Computing'),
 '2026-03-24', 'C'),
((SELECT student_id FROM students WHERE email = 'eva.martinez@csusm.edu'),
 (SELECT course_id FROM courses WHERE title = 'Database Systems'),
 '2026-03-24', 'B'),
((SELECT student_id FROM students WHERE email = 'eva.martinez@csusm.edu'),
 (SELECT course_id FROM courses WHERE title = 'Operating Systems'),
 '2026-03-24', 'A');
