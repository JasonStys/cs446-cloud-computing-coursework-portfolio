Cloud Computing Week 9 Labs 1 and 2

This archive contains the code and script files created and used for the two labs.

Lab1/
- lab1_schema.sql
- lab1_sample_data.sql
- lab1_queries.sql
- lab1_app.py

Lab2/
- main.py
- requirements.txt

Other files:
- commands_used.txt
